

public class DataMessages_DeVera {
    public static String [] messages = {"Correct Input", "Invalid Data Type", "Customer number must not be lower than 1000", "Customer number must not be higher than 5000", "Quantity is too low",  "Price must not be less than 0", "Price must not be more than 10000"};
}                                               //0             1                       2                           3                                                       4                                           5                                                                          