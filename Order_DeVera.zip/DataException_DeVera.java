

public class DataException_DeVera extends Exception {
    public DataException_DeVera (String n){
        super(n);
    }
}
