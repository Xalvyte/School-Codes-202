public class OrderException extends Exception {
    public OrderException(String n){
        super(n);
    }
    
}
