public class OrderMessages {
    final static String [] Error = {"Complete order.", "Inputted data is not numeric.", "The item number is too low.", "The item number is too high.", "The quantity ordered is too low.", "The quantity ordered is too high.", "The item number is not a currently valid item."};
}
