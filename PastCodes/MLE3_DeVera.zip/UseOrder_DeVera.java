import java.util.*;

public class UseOrder_DeVera {
    static Scanner input = new Scanner(System.in);
    public static void main(String[] args) {
        Order_DeVera o1 = new Order_DeVera();
        ShippedOrder_DeVera o2 = new ShippedOrder_DeVera();

        System.out.println("Order Details");
        System.out.print("Enter Customer number\t:\t"); o1.setCusNum(input.nextInt()); input.nextLine();
        System.out.print("Enter Item description:\t:\t"); o1.setItemDesc(input.nextLine());
        System.out.print("Enter Quantity\t\t:\t"); o1.setQuan(input.nextInt());
        System.out.print("Enter Price\t\t: Php\t"); o1.setUnitPrice(input.nextDouble());

        System.out.println("Shipper Order Details");
        System.out.print("Enter Customer number\t:\t"); o2.setCusNum(input.nextInt()); input.nextLine();
        System.out.print("Enter Item description:\t:\t"); o2.setItemDesc(input.nextLine());
        System.out.print("Enter Quantity\t\t:\t"); o2.setQuan(input.nextInt());
        System.out.print("Enter Price\t\t: Php\t"); o2.setUnitPrice(input.nextDouble());

        System.out.println();
        o1.display();
        System.out.println();
        o2.display();
    }
}
